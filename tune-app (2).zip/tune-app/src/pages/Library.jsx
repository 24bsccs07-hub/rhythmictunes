import React from 'react';
import './Library.css';

const Library = () => {
  const tracks = [
    {
      title: 'Ride or Die',
      artist: 'sevdaliza',
      duration: '3:50',
      audio: '/audio/ride-die.mp3',
      image: '/image/sevdaliza.jpeg'
    },
    {
      title: 'cry for me ',
      artist: 'the weeknd',
      duration: '3:57',
      audio: '/audio/cry-for-me.mp3',
      image: '/image/cry-for-me.jpeg'
    },
    {
      title: 'young and beautiful',
      artist: 'lana del rey',
      duration: '4:23',
      audio: '/audio/perfect.mp3',
      image: '/image/ypung&beautiful.jpeg'
    },
    {
      title: 'love story',
      artist: 'taylor swift',
      duration: '4:45',
      audio: '/audio/love-story.mp3',
      image: '/image/lovestory.jpeg'
    }
  ];

  return (
    <main className="main-content">
      <h1>Your Library</h1>
      <p>Manage your music collection</p>
      
      <div className="tracks-section">
        <h2>Your Music</h2>
        <div className="track-list">
          {tracks.map((track, index) => (
            <div key={index} className="track-item">
              <img src={track.image} alt={track.title} className="track-image" />
              <div className="track-info">
                <h3>{track.title}</h3>
                <p>{track.artist}</p>
              </div>
              <div className="track-controls">
                <audio controls autoPlay={index === 0}>
                  <source src={track.audio} type="audio/wav" />
                </audio>
                <span className="duration">{track.duration}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
};

export default Library;