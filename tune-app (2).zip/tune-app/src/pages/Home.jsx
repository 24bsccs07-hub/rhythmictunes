import React from 'react';
import './Home.css';

const Home = () => {
  const genres = [
    {
      title: 'Pop Music',
      image: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=200&fit=crop',
      description: 'Latest pop hits',
      duration: '3:45',
      audio: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav'
    },
    {
      title: 'Melody',
      image: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=300&h=200&fit=crop',
      description: 'Beautiful melodies',
      duration: '4:12',
      audio: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav'
    },
    {
      title: 'Love Songs',
      image: 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=300&h=200&fit=crop',
      description: 'Romantic collection'
    },
    {
      title: 'Emotional Songs',
      image: 'https://images.unsplash.com/photo-1445985543470-41fba5c3144a?w=300&h=200&fit=crop',
      description: 'Deep emotions'
    }
  ];

  return (
    <main className="main-content">
      <h1>Welcome to TuneApp</h1>
      <p>Your music streaming experience starts here!</p>
      
      <div className="genres-section">
        <h2>Music Genres</h2>
        <div className="genre-cards">
          {genres.map((genre, index) => (
            <div key={index} className="genre-card">
              <img src={genre.image} alt={genre.title} />
              <div className="card-content">
                <h3>{genre.title}</h3>
                <p>{genre.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
};

export default Home;