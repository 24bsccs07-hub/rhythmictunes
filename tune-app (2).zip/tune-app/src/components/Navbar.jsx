import { Link } from 'react-router-dom';
import { Music, Search, Home, Library, Heart, User } from 'lucide-react';
import './Navbar.css';

const Navbar = () => {
  
  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <Music size={24} />
        <h2>TuneApp</h2>
      </div>
      
      <div className="navbar-center">
        <div className="search-container" >
          <input 
            type="text" 
            placeholder="Search songs, artists, albums..."
            className="search-input"
          />
          <button className="search-btn">
            <Search size={18} />
          </button>
        </div>
      </div>

      <div className="navbar-actions">
        <Link to="/" className="nav-btn">
          <Home size={18} />
          Home
        </Link>
        <Link to="/library" className="nav-btn">
          <Library size={18} />
          Library
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;